package ProgramSorter;

import java.io.*;
import java.util.*;

public class FileSearcher {
    public static void main(String[] args) {
        System.out.println("РИБО-01-21, Бобровский С.И., Практика №5, Вариант №4");
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Введите путь для поиска файлов: ");
            String directoryPath = reader.readLine();
            System.out.println("Поиск " + directoryPath + "...");
            File directory = new File(directoryPath);
            List<File> foundFiles = findFiles(directory);
            if (foundFiles.isEmpty()) {
                System.out.println("Файлы расширения .dox, .docx, .txt, .exe, .jpg, mp3 не были найдены...");
                System.exit(0);
            }
            Collections.sort(foundFiles, new Comparator<File>() {
                @Override
                public int compare(File file1, File file2) {
                    return file1.getAbsolutePath().compareTo(file2.getAbsolutePath());
                }
            });


            for (File file : foundFiles) {
                String fileName = file.getName();
                long fileSize = file.length();
                System.out.println(file.getAbsolutePath() + "\t" + fileName + "\t" + fileSize + " байтов");
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Ошибка обработки каталога");
        }
    }


    private static List<File> findFiles(File directory) {
        List<File> foundFiles = new ArrayList<>();
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    List<File> nestedFiles = findFiles(file);
                    foundFiles.addAll(nestedFiles);
                } else {
                    String fileName = file.getName().toLowerCase();
                    if (fileName.endsWith(".doc") ||
                            fileName.endsWith(".docx") ||
                            fileName.endsWith(".txt") ||
                            fileName.endsWith(".exe") ||
                            fileName.endsWith(".mp3") ||
                            fileName.endsWith(".jpg")) {
                        foundFiles.add(file);
                    }
                }
            }
        }
        return foundFiles;
    }
}

